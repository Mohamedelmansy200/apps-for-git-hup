package com.spongebob.puzzles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
