import 'dart:ui';

const primary = Color(0xFFf7e948);
const secondary = Color(0xFFffd389);
const border = Color(0xFFfff360);
const background = Color(0xFFf0e33f);
